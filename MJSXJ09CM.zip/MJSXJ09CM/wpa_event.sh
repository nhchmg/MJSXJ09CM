#!/bin/sh

case "$2" in
    CONNECTED)
    pidof framegrabber && echo "running fg" || /mnt/data/bin/custom_startup.sh

		PID=`/bin/pidof udhcpc`;
        /bin/kill -SIGUSR1 ;
;;
    DISCONNECTED)
        ;;
esac
